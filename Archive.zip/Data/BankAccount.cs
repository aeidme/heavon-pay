namespace HeavonApp.Data;

public class BankAccount
{
    public DateTime RegistrationDate { get; set; }

    public string InternationalBankAccountNumber { get; set; }

    public int Balance { get; set; }

    public string? Alias { get; set; }

    public Boolean isJoint { get; set; }
}
