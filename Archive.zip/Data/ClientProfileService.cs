namespace HeavonApp.Data;

public class ClientProfileService
{
    private static readonly string[] Summaries = new[]
    {
        "Freezing", "Bracing", "Hot", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

    public Task<ClientProfile[]> GetForecastAsync(DateTime startDate)
    {
        return Task.FromResult(Enumerable.Range(1, 5).Select(index => new ClientProfile
        {
            RegistrationDate = startDate.AddDays(index),
            Balance = Random.Shared.Next(0, 525),
            Summary = Summaries[Random.Shared.Next(Summaries.Length)]
        }).ToArray());
    }
}
