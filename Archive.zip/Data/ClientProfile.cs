namespace HeavonApp.Data;

public class ClientProfile
{
    public DateTime RegistrationDate { get; set; }

    public List<BankAccount> BankAccounts { get; set; }

    public int Balance { get; set; }

    public string? Summary { get; set; }
}
